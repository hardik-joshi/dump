package com.demoschool.controller;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.demoschool.model.Login;
import com.demoschool.repository.LoginRepository;
import com.demoschool.util.NetworkUtil;

@SuppressWarnings("serial")
public class LoginController extends HttpServlet{
	private LoginRepository loginRepository;
	public LoginController(){
		super();
		loginRepository = new LoginRepository();
	}
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException{
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		String strAction = request.getParameter("action");
		
		if (loginRepository != null) {
			if (strAction.equals("login")) {
				try {
					JSONObject jsonObject = NetworkUtil.getJsonObjectFromHttpRequest(request);
					String result = verifyLoginDetail(jsonObject);
					response.getWriter().print(result);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	private String verifyLoginDetail(JSONObject jsonObject){
		String value = "Failed";
		try{
			Login login = new Login();
			
			String strUserName = (String) jsonObject.get("userName");
			String password = (String) jsonObject.get("password");
			
			login.setUserName(strUserName);
			login.setPassword(password);
			
			login = loginRepository.verifyLogin(login);
			if(login.getLoginId()!=0){
				value= "Success";
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return value;
	}
}
