package com.demoschool.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demoschool.util.DbUtil;

public class UserTypeRepository {
	private Connection dbConnection;
	
	public UserTypeRepository(){
		dbConnection = DbUtil.getConnection();
	}
	
	public int getUserTypeIdFromUserType(String userType) throws SQLException{
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nUserTypeId = 0;
		try{
			sbSql = new StringBuilder("SELECT id FROM usertype WHERE name LIKE ?");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setString(1, userType);
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				nUserTypeId = oRs.getInt("id");
			}
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			if(oRs != null)
				oRs.close();
			if(oPrStmt != null)
				oPrStmt.close();
		}
		return nUserTypeId;
	}
}
