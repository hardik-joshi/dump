angular.module("LoginApp", []).controller("LoginController",function($scope, $http) {
	$scope.verifyLogin = function(){
		if(!validateLoginFields()){
			return;
		}
		var dataObj = {
				userName : $scope.userName,
				password : $scope.password,
		};	
		var res = $http.post('SignInDetails?action=login', dataObj);
		res.success(function(data, status, headers, config) {
			if(data == "Success"){
				//window.location.href = "index.html";
				new PNotify({
                    title: 'Successfully Login',
                    text: 'Welcome to Demo School',
                    type: 'success',
                    styling: 'bootstrap3'
                });
			}
			else if(data == "Failed"){
				new PNotify({
                    title: 'Login Failed',
                    text: 'Username/Password is Incorrect',
                    type: 'error',
                    styling: 'bootstrap3'
                });
			}
			$scope.password = "";
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	
	};
	
	$scope.saveRegisterInfo = function(){
		if(!validateRegisterFields()){
			return;
		}
		var dataObj = {
				schoolName : $scope.schoolName,
				schoolCode : $scope.schoolCode,
				fullName : $scope.fullName,
				email : $scope.email,
				phoneNo : $scope.phoneNo,
				password : $scope.password
		};
		var res = $http.post('RegisterController?action=register', dataObj);
		res.success(function(data, status, headers, config) {
			if(data == "Success"){
				//window.location.href = "index.html";
				new PNotify({
                    title: 'Register Successfully',
                    text: 'You may now login to our website',
                    type: 'success',
                    styling: 'bootstrap3'
                });
			}
			else if(data == "Failed"){
				new PNotify({
                    title: 'Registration Failed',
                    text: 'Some of the field is wrongly entered. Please try again',
                    type: 'error',
                    styling: 'bootstrap3'
                });
			}
		});
		res.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
		});	
		$scope.schoolName = "";
		$scope.schoolCode = "";
		$scope.fullName = "";
		$scope.email = "";
		$scope.phoneNo = "";
		$scope.password = "";
		$scope.cfmPassword = "";
	};
	
	$scope.checkAvailability = function(){
		$('#availabilitySpinner').show();
		var dataObj = {
			email : $scope.email
		};	
		if($scope.email == ""){
			return;
		}
		
//		var res = $http.post('RegisterController?action=checkAvailability', dataObj);
//		res.success(function(data, status, headers, config) {
//			if(data == "Success"){
//				$('#schoolEmail').parsley().removeError('checkEmailAvailable');
//				//window.location.href = "index.html";
//			}
//			else if(data == "Failed"){
//				$('#schoolEmail').parsley().removeError('checkEmailAvailable');
//				$('#schoolEmail').parsley().addError('checkEmailAvailable', { message: 'Email is not available' });
//			}
//			$('#availabilitySpinner').hide();
//		});
//		res.error(function(data, status, headers, config) {
//			alert( "failure message: " + JSON.stringify({data: data}));
//			$('#availabilitySpinner').hide();
//		});	
		
		var formdata = $.param({FormData : angular.toJson(dataObj)});
        var url = 'RegisterController?action=checkAvailability';
        var promise =  $http({
         method: 'POST',
         url: url,
         data: formdata,
         headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        });
        promise.success(function(data, status, headers, config) {
			if(data == "Success"){
				$('#schoolEmail').parsley().removeError('checkEmailAvailable');
				//window.location.href = "index.html";
			}
			else if(data == "Failed"){
				$('#schoolEmail').parsley().removeError('checkEmailAvailable');
				$('#schoolEmail').parsley().addError('checkEmailAvailable', { message: 'Email is not available' });
			}
			$('#availabilitySpinner').hide();
		});
		promise.error(function(data, status, headers, config) {
			alert( "failure message: " + JSON.stringify({data: data}));
			$('#availabilitySpinner').hide();
		});	
//		var url="RegisterController?action=checkAvailability";
//		var data="FormData=" + JSON.stringify(dataObj);
//		$http({
//		    url: url,
//		    dataType: 'json',
//		    method: 'POST',
//		    data: data,
//		    headers: {
//		        "Content-Type": "application/json"
//		    }
//
//		}).success(function(response){
//		    $scope.response = response;
//		}).error(function(error){
//		   `2 $scope.error = error;
//		});
	};
	
	function validateLoginFields(){
		var instance = $('#loginUsername').parsley();
		if(!instance.isValid()){
			return false;
		}
		var instance = $('#loginPassword').parsley();
		if(!instance.isValid()){
			return false;
		}
		return true;
	}
	
	function validateRegisterFields(){
		var instance = $('#schoolName').parsley();
		if(!instance.isValid()){
			return false;
		}
		var instance = $('#fullName').parsley();
		if(!instance.isValid()){
			return false;
		}
		var instance = $('#schoolEmail').parsley();
		if(!instance.isValid()){
			return false;
		}
		var instance = $('#schoolPhone').parsley();
		if(!instance.isValid()){
			return false;
		}
		var instance = $('#registerPassword').parsley();
		if(!instance.isValid()){
			return false;
		}
		var instance = $('#registerCnfPassword').parsley();
		if(!instance.isValid()){
			return false;
		}
		var instance = $('#schoolCode').parsley();
		if(!instance.isValid()){
			return false;
		}
		return true;
	}
});