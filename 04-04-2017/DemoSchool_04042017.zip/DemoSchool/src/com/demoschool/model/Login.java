package com.demoschool.model;

public class Login {
	private int loginId = 0;
	private Person person = null;
	private String userName = "";
	private String password = "";
	private UserType userType = null;
	private String resetUrl = "";
	public int getLoginId() {
		return loginId;
	}
	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserType getUserType() {
		return userType;
	}
	public void setUserType(UserType userType) {
		this.userType = userType;
	}
	public String getResetUrl() {
		return resetUrl;
	}
	public void setResetUrl(String resetUrl) {
		this.resetUrl = resetUrl;
	}
}
