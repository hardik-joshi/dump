package com.demoschool.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demoschool.model.Login;
import com.demoschool.model.Person;
import com.demoschool.model.UserType;
import com.demoschool.util.DbUtil;

public class LoginRepository {
	private Connection dbConnection;
	
	public LoginRepository(){
		dbConnection = DbUtil.getConnection();
	}
	
	public int saveLogin(Login login) throws SQLException{
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nLoginId = 0;
		int nParam = 0;
		try{
			// Person Information
			sbSql = new StringBuilder("INSERT INTO login (personid,username,password,usertypeid,reseturl");
			sbSql.append(") VALUES (");
			sbSql.append("?,?,?,?,?");
			sbSql.append(")");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setInt(++nParam, login.getPerson().getPersonId());
			oPrStmt.setString(++nParam, login.getUserName());
			oPrStmt.setString(++nParam, login.getPassword());
			oPrStmt.setInt(++nParam, login.getUserType().getUserTypeId());
			oPrStmt.setString(++nParam, login.getResetUrl());
			oPrStmt.executeUpdate();
			oPrStmt.close();
			
			sbSql.setLength(0);
			sbSql.append("SELECT MAX(id) AS maxLoginId FROM login");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				nLoginId = oRs.getInt("maxLoginId");
			}
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			if(oRs != null)
				oRs.close();
			if(oPrStmt != null)
				oPrStmt.close();
		}
		return nLoginId;
	}
	
	public Login verifyLogin(Login login){
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nParam = 0;
		try{
			login.setLoginId(0);
			sbSql = new StringBuilder("SELECT id,personid,usertypeid,reseturl FROM login WHERE username=? AND password=?");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setString(++nParam, login.getUserName());
			oPrStmt.setString(++nParam, login.getPassword());
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				int nLoginId = oRs.getInt("id");
				int nPersonId = oRs.getInt("personid");
				int nUserTypeId = oRs.getInt("usertypeid");
				String strResetUrl = oRs.getString("reseturl");
				login.setLoginId(nLoginId);
				Person person = new Person();
				person.setPersonId(nPersonId);
				login.setPerson(person);
				UserType userType = new UserType();
				userType.setUserTypeId(nUserTypeId);
				login.setUserType(userType);
				login.setResetUrl(strResetUrl);
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return login;
	}
	
	public boolean checkAvailability(String email){
		boolean isAvailable = true;
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nParam = 0;
		try{
			sbSql = new StringBuilder("SELECT id FROM login WHERE username=?");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setString(++nParam, email);
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				isAvailable = false;
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return isAvailable;
	}
}
