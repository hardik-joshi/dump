package com.demoschool.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demoschool.model.Teacher;
import com.demoschool.util.DbUtil;

public class TeacherRepository {
	private Connection dbConnection;
	
	public TeacherRepository(){
		dbConnection = DbUtil.getConnection();
	}
	
	public int saveTeacher(Teacher teacher) throws SQLException{
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nPersonId = 0;
		int nTeacherId = 0;
		int nParam = 0;
		try{
			// Person Information
			PersonRepository personRepository = new PersonRepository();
			nPersonId = personRepository.savePerson(teacher.getPerson());
			
			// Teacher Information
			sbSql = new StringBuilder("INSERT INTO teacher (personid,empno,title,maritalstatus,employmentdate,");
			sbSql.append("initials,familyname,spousename,ssn,degree,certification,experience");
			sbSql.append(") VALUES (");
			sbSql.append("?,?,?,?,?,?,?,?,?,?,?,?");
			sbSql.append(")");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setInt(++nParam, nPersonId);
			oPrStmt.setString(++nParam, teacher.getEmpNo());
			oPrStmt.setString(++nParam, teacher.getTitle());
			oPrStmt.setString(++nParam, teacher.getMaritalStatus());
			oPrStmt.setString(++nParam, teacher.getEmploymentDate());
			oPrStmt.setString(++nParam, teacher.getInitials());
			oPrStmt.setString(++nParam, teacher.getFamilyName());
			oPrStmt.setString(++nParam, teacher.getSpouseName());
			oPrStmt.setString(++nParam, teacher.getSsn());
			oPrStmt.setString(++nParam, teacher.getDegree());
			oPrStmt.setString(++nParam, teacher.getCertification());
			oPrStmt.setString(++nParam, teacher.getExperience());
			oPrStmt.executeUpdate();
			oPrStmt.close();
			
			sbSql.setLength(0);
			sbSql.append("SELECT MAX(teacherid) AS maxTeacherId FROM teacher");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				nTeacherId = oRs.getInt("maxTeacherId");
			}
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			if(oRs != null)
				oRs.close();
			if(oPrStmt != null)
				oPrStmt.close();
		}
		return nTeacherId;
	}
}