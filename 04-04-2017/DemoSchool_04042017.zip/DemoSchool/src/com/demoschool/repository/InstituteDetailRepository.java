package com.demoschool.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demoschool.model.InstituteDetail;
import com.demoschool.util.DbUtil;

public class InstituteDetailRepository {
	private Connection dbConnection;
	
	public InstituteDetailRepository(){
		dbConnection = DbUtil.getConnection();
	}
	
	public int saveInstituteDetail(InstituteDetail instituteDetail) throws SQLException{
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nTeacherId = 0;
		int nInstituteId = 0;
		int nParam = 0;
		try{
			// Teacher Information
			TeacherRepository teacherRepository = new TeacherRepository();
			nTeacherId = teacherRepository.saveTeacher(instituteDetail.getTeacher());
			
			// Institute Information
			sbSql = new StringBuilder("INSERT INTO institutedetail (teacherid,institutename,institutecode,address,email,phoneno,logo)");
			sbSql.append("VALUES (");
			sbSql.append("?,?,?,?,?,?,?");
			sbSql.append(")");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setInt(++nParam, nTeacherId);
			oPrStmt.setString(++nParam, instituteDetail.getInstituteName());
			oPrStmt.setString(++nParam, instituteDetail.getInstituteCode());
			oPrStmt.setString(++nParam, instituteDetail.getAddress());
			oPrStmt.setString(++nParam, instituteDetail.getEmail());
			oPrStmt.setString(++nParam, instituteDetail.getPhoneNo());
			oPrStmt.setString(++nParam, instituteDetail.getLogo());
			oPrStmt.executeUpdate();
			oPrStmt.close();
			
			sbSql.setLength(0);
			sbSql.append("SELECT MAX(instituteid) AS maxInstituteId FROM institutedetail");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				nInstituteId = oRs.getInt("maxInstituteId");
			}
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			if(oRs != null)
				oRs.close();
			if(oPrStmt != null)
				oPrStmt.close();
		}
		return nInstituteId;
	}
	
	public int getPersonIdFromInstitute(int nInstituteId){
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nPersonId = 0;
		try{
			sbSql = new StringBuilder("SELECT personid FROM teacher WHERE teacherid = (SELECT teacherid FROM institutedetail WHERE instituteid = ?)");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setInt(1, nInstituteId);
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				nPersonId = oRs.getInt("personid");
			}
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return nPersonId;
	}
}
