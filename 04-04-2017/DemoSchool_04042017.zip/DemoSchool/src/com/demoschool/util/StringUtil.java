package com.demoschool.util;

public class StringUtil {
	/***
	 * author: Hardik Joshi
	 * use: To parse first and last name from full name.
	 */
	public static String[] parseFullName(String fullName){
		String[] str = new String[2];
		
		int start = fullName.indexOf(' ');

	    if (start >= 0) {
	        str[0] = fullName.substring(0, start);
	        str[1] = fullName.substring(start + 1, fullName.length());
	    }
	    else{
	    	str[0] = fullName;
	    	str[1] = "";		
	    }
		return str;
	}
}
