package com.demoschool.controller;

import java.io.*;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import org.json.*;

import com.demoschool.model.*;
import com.demoschool.repository.*;
import com.demoschool.util.NetworkUtil;
import com.demoschool.util.StringUtil;

@SuppressWarnings("serial")
public class InstituteDetailController extends HttpServlet{
	private InstituteDetailRepository instituteDetailRepository;
	public InstituteDetailController(){
		super();
		instituteDetailRepository = new InstituteDetailRepository();
	}
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException{
		String result = "";
		String strAction = request.getParameter("action");
		String str = request.getParameter("FormData");
		if (instituteDetailRepository != null) {
			if (strAction.equals("register")) {
				try {
					JSONObject jsonObject = NetworkUtil.getJsonObjectFromHttpRequest(request);
					result = registerInstituteDetail(jsonObject);
					response.getWriter().print(result);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if(strAction.equals("checkAvailability")){
				try{
					JSONObject jsonObject = NetworkUtil.getJsonObjectFromHttpRequest(request);
					result = checkAvailabilityForRegister(jsonObject);
					response.getWriter().print(result);
				}
				catch(Exception e){
					e.printStackTrace();	
				}
			}
		}
	}
	
	private String registerInstituteDetail(JSONObject jsonObject){
		String value = "";
		try{
			UserType userType = new UserType();
			Person person = new Person();
			Teacher teacher = new Teacher();
			Login login = new Login();
			InstituteDetail instituteDetail = new InstituteDetail();
			
			String strSchoolName = (String) jsonObject.get("schoolName");
			String strSchoolCode = (String) jsonObject.get("schoolCode");
			String strFullName = (String) jsonObject.get("fullName");
			String strEmail = (String) jsonObject.get("email");
			String strPhoneNo = (String) jsonObject.get("phoneNo");
			String strPassword = (String) jsonObject.get("password");
			String strUserType = "teacher";
			
			// UserType Detail
			UserTypeRepository userTypeRepo = new UserTypeRepository();
			int nUserTypeId = userTypeRepo.getUserTypeIdFromUserType(strUserType);
			
			// Set User Type Detail
			userType.setUserTypeId(nUserTypeId);
			userType.setUserTypeName(strUserType);
			
			// Set Person Detail
			String[] strPersonName = StringUtil.parseFullName(strFullName);
			person.setFirstName(strPersonName[0]);
			person.setLastName(strPersonName[1]);
			person.setEmail(strEmail);
			person.setCellPhone(strPhoneNo);
			person.setUserType(userType);
			
			// Set Teacher Detail
			teacher.setPerson(person);
			
			// Set Institute Detail
			instituteDetail.setInstituteName(strSchoolName);
			instituteDetail.setInstituteCode(strSchoolCode);
			instituteDetail.setTeacher(teacher);
			
			// Save Institute Detail
			int nInstituteId = instituteDetailRepository.saveInstituteDetail(instituteDetail);
			
			// Find person id from institute id which is used to store in Login Details
			int nPersonId = 0;
			if(nInstituteId!=0){
				nPersonId = instituteDetailRepository.getPersonIdFromInstitute(nInstituteId);
				person.setPersonId(nPersonId);
			}
			
			// Set Login Detail
			login.setUserName(strEmail);
			login.setPassword(strPassword);
			login.setPerson(person);
			login.setUserType(userType);
			
			// Save Login Detail
			LoginRepository loginRepository = new LoginRepository();
			loginRepository.saveLogin(login);
			
			value = "Success";
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return value;
	}
	
	private String checkAvailabilityForRegister(JSONObject jsonObject){
		String result = "Failed";
		String strEmail = "";
		boolean isAvailable = false;
		try {
			strEmail = (String) jsonObject.get("email");
			
			LoginRepository loginRepository = new LoginRepository();
			isAvailable = loginRepository.checkAvailability(strEmail);
			if(isAvailable){
				result="Success";
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
}
