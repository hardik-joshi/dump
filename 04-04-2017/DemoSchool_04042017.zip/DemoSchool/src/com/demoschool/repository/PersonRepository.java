package com.demoschool.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demoschool.model.Person;
import com.demoschool.util.DbUtil;

public class PersonRepository {
	private Connection dbConnection;
	
	public PersonRepository(){
		dbConnection = DbUtil.getConnection();
	}
	
	public int savePerson(Person person) throws SQLException{
		PreparedStatement oPrStmt = null;
		ResultSet oRs = null;
		StringBuilder sbSql = null;
		int nPersonId = 0;
		int nParam = 0;
		try{
			// Person Information
			sbSql = new StringBuilder("INSERT INTO person (firstname,lastname,preferredname,birthdate,gender,");
			sbSql.append("nationality,homeaddress,homephone,cellphone,email,city,state,zipcode,country,photo,usertypeid");
			sbSql.append(") VALUES (");
			sbSql.append("?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?");
			sbSql.append(")");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oPrStmt.setString(++nParam, person.getFirstName());
			oPrStmt.setString(++nParam, person.getLastName());
			oPrStmt.setString(++nParam, person.getPreferredName());
			oPrStmt.setString(++nParam, person.getBirthdate());
			oPrStmt.setString(++nParam, person.getGender());
			oPrStmt.setString(++nParam, person.getNationality());
			oPrStmt.setString(++nParam, person.getHomeAddress());
			oPrStmt.setString(++nParam, person.getHomePhone());
			oPrStmt.setString(++nParam, person.getCellPhone());
			oPrStmt.setString(++nParam, person.getEmail());
			oPrStmt.setString(++nParam, person.getCity());
			oPrStmt.setString(++nParam, person.getState());
			oPrStmt.setString(++nParam, person.getZipcode());
			oPrStmt.setString(++nParam, person.getCountry());
			oPrStmt.setString(++nParam, person.getPhoto());
			oPrStmt.setInt(++nParam, person.getUserType().getUserTypeId());
			oPrStmt.executeUpdate();
			oPrStmt.close();
			
			sbSql.setLength(0);
			sbSql.append("SELECT MAX(personid) AS maxPersonId FROM person");
			oPrStmt = dbConnection.prepareStatement(sbSql.toString());
			oRs = oPrStmt.executeQuery();
			if(oRs.next()){
				nPersonId = oRs.getInt("maxPersonId");
			}
		}
		catch(SQLException ex){
			ex.printStackTrace();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		finally{
			if(oRs != null)
				oRs.close();
			if(oPrStmt != null)
				oPrStmt.close();
		}
		return nPersonId;
	}
}
