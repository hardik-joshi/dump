package com.demoschool.util;

import java.io.BufferedReader;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;

public class NetworkUtil {
	public static JSONObject getJsonObjectFromHttpRequest(HttpServletRequest request){
		JSONObject jsonObject = null;
		StringBuffer jb = null;
		String line = null;
		try{
			jb = new StringBuffer("");
			BufferedReader reader = request.getReader();
			while ((line = reader.readLine()) != null)
				jb.append(line);
			jsonObject = new JSONObject(jb.toString());
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		return jsonObject;
	}
}
